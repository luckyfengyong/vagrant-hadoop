#!/usr/bin/env python
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

"""

from resource_management import *
import status_params

# server configurations
config = Script.get_config()

openlava_root = config['configurations']['global']['app_root']
conf_dir = format("{openlava_root}/etc")
daemon_script = format("{openlava_root}/etc/openlava")
addhost_cmd = format("{openlava_root}/bin/lsaddhost")
source_env = format("{openlava_root}/etc/openlava.sh")

hostname = config["hostname"]

mbd_port = config['configurations']['global']['master_mbd_port']
zk_host = config['configurations']['global']['zookeeper_quorum']
zk_parent_znode = config['configurations']['global']['zookeeper_parent_znode']
cluster_name = config["clusterName"]
zk_znode = str(zk_parent_znode) + "/" + str(cluster_name)

java64_home = config['hostLevelParams']['java_home']
input_conf_files_dir = config['configurations']['global']['app_input_conf_dir']

pid_dir = status_params.pid_dir
openlava_user = status_params.openlava_user
